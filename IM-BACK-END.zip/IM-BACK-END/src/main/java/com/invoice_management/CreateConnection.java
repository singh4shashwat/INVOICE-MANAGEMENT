package com.invoice_management;

import java.sql.Connection;
import java.sql.DriverManager;

public class CreateConnection {
	static Connection con;

	public static Connection CC() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String user = "root";
			String password = "root";
			String url = "jdbc:mysql://localhost:3306/grey_goose";

			con = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
}
