import React from "react";
import Header from "./Component/HEADER/Header";
import Footer from "./Component/FOOTER/Footer";
import MainData from "./Component/MAIN/MainData";

function App() {
  return (
    <>
      <Header />
      <MainData />
      <Footer />
    </>
  );
}

export default App;
