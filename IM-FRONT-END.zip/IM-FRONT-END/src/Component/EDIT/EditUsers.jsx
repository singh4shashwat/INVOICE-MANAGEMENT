import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import { makeStyles } from "@material-ui/core/styles";
import Box from "@mui/material/Box";
import { DialogActions, TextField } from "@mui/material";

const useStyles = makeStyles(() => ({
  textField: {
    margin: 9,
    width: "28ch",
    background: "rgb(232, 249, 250)",
    borderRadius: "4px",
  },
}));

export default function EditUsers({
  open,
  invoice_currency,
  cust_payment_terms,
  changeHandler,
  handleClose,
  handleClickOpen,
}) {
  const classes = useStyles();
  return (
    <div>
      <Button
        variant="outlined"
        style={{ color: "white", width: "10vw" }}
        onClick={handleClickOpen}
      >
        EDIT
      </Button>
      <Dialog fullWidth maxWidth="sm" open={open} onClose={handleClose}>
        <Box
          component="form"
          sx={{
            display: "flex",
            flexWrap: "wrap",
            backgroundColor: "#273D4A",
            color: "white",
          }}
          noValidate
          autoComplete="off"
        >
          <DialogTitle>Edit</DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              name="invoice_currency"
              id="invoice_currency"
              label="Invoice Currency"
              type="text"
              onChange={changeHandler}
              value={invoice_currency}
              variant="standard"
              className={classes.textField}
            />
            <TextField
              autoFocus
              name="cust_payment_terms"
              margin="dense"
              id="cust_payment_terms"
              label="Customer Payment Terms"
              type="text"
              onChange={changeHandler}
              value={cust_payment_terms}
              variant="standard"
              className={classes.textField}
            />
          </DialogContent>
          <DialogActions>
            <Button
              variant="outlined"
              style={{ color: "white", width: "288px", borderColor: "white" }}
              onClick={() => handleClose(true)}
            >
              Edit
            </Button>
            <Button
              variant="outlined"
              style={{ color: "white", width: "288px", borderColor: "white" }}
              onClick={() => handleClose(false)}
            >
              Cancel
            </Button>
          </DialogActions>
        </Box>
      </Dialog>
    </div>
  );
}
