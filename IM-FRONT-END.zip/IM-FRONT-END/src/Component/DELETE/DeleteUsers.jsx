import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import { DialogContentText } from "@mui/material";

export default function DeleteUsers({
  dltOpen,
  handleClickDltOpen,
  handleDltClose,
}) {
  return (
    <>
      <Button
        variant="outlined"
        style={{ color: "white", width: "10vw" }}
        onClick={handleClickDltOpen}
      >
        DELETE
      </Button>
      <Dialog open={dltOpen} onClose={handleDltClose}>
        <DialogTitle style={{ backgroundColor: "#273d4a", color: "white" }}>
          Delete Records?
        </DialogTitle>
        <DialogContent style={{ backgroundColor: "#273d4a" }}>
          <DialogContentText style={{ color: "white" }}>
            Are you sure you want to delete these record[s]?
          </DialogContentText>
        </DialogContent>
        <DialogActions style={{ backgroundColor: "#273d4a" }}>
          <Button
            variant="outlined"
            style={{ color: "white", width: "500px", borderColor: "white" }}
            onClick={() => handleDltClose(true)}
          >
            Delete
          </Button>
          <Button
            variant="outlined"
            style={{ color: "white", width: "500px", borderColor: "white" }}
            onClick={() => handleDltClose(false)}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
