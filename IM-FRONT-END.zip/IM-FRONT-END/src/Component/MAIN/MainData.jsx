import React, { useEffect, useState } from "react";
import Button from "@mui/material/Button";
import ButtonGroup from "@mui/material/ButtonGroup";
import Grid from "@mui/material/Grid";
import RefreshIcon from "@material-ui/icons/Refresh";
import Box from "@mui/material/Box";
import DeleteUsers from "../DELETE/DeleteUsers";
import EditUsers from "../EDIT/EditUsers";
import AddUsers from "../ADD/AddUsers";
import { DataGrid } from "@mui/x-data-grid";
import { advSrch, deleteUser, getData, updateUser } from "../../services/data";
import Advance from "../ADV SEARCH/Advance";
import { TextField } from "@mui/material";

var col = [
  { title: "sl_no", field: "sl_no", headerName: "Sl no" },
  {
    title: "business_code",
    field: "business_code",
    headerName: "Business Code",
    width: 100,
  },
  {
    title: "cust_number",
    field: "cust_number",
    headerName: "Customer Number",
    width: 100,
  },
  {
    title: "clear_date",
    field: "clear_date",
    headerName: "Clear Date",
    width: 100,
  },
  {
    title: "buisness_year",
    field: "buisness_year",
    headerName: "Business Year",
    width: 100,
  },
  { title: "doc_id", field: "doc_id", headerName: "Document Id", width: 100 },
  {
    title: "posting_date",
    field: "posting_date",
    headerName: "Posting Date",
    width: 100,
  },
  {
    title: "document_create_date",
    field: "document_create_date",
    headerName: "Document Create Date",
    width: 100,
  },
  {
    title: "due_in_date",
    field: "due_in_date",
    headerName: "Due Date",
    width: 100,
  },
  {
    title: "invoice_currency",
    field: "invoice_currency",
    headerName: "Invoice Currency",
    width: 100,
  },
  {
    title: "document_type",
    field: "document_type",
    headerName: "Document Type",
    width: 100,
  },
  {
    title: "posting_id",
    field: "posting_id",
    headerName: "Posting Id",
    width: 100,
  },
  {
    title: "total_open_amount",
    field: "total_open_amount",
    headerName: "Total Open Amount",
    width: 100,
  },
  {
    title: "baseline_create_date",
    field: "baseline_create_date",
    headerName: "Baseline Create Date",
    width: 100,
  },
  {
    title: "cust_payment_terms",
    field: "cust_payment_terms",
    headerName: "Customer Payment Terms",
    width: 100,
  },
  {
    title: "invoice_id",
    field: "invoice_id",
    headerName: "Invoice Id",
    width: 100,
  },
];

function MainData() {
  const [data, setData] = useState([]);

  useEffect(async () => {
    setData(await getData());
  }, []);

  // EDIT

  const [open, setOpen] = React.useState(false);
  const [selectedRows, setSelectedRows] = React.useState([]);
  const [edit, setEdit] = useState({
    sl_no: "",
    invoice_currency: "",
    cust_payment_terms: "",
  });

  const { invoice_currency, cust_payment_terms } = edit;

  const handleClickOpen = () => {
    if (selectedRows.length === 1) {
      setOpen({
        open: true,
      });
      setEdit({
        sl_no: selectedRows[0].sl_no,
        invoice_currency: selectedRows[0].invoice_currency,
        cust_payment_terms: selectedRows[0].cust_payment_terms,
      });
    } else {
      alert("Please select 1 Row at a time...");
    }
  };

  const changeHandler = (e) => {
    const { name, value } = e.target;
    setEdit({ ...edit, [name]: value });
  };

  const handleClose = async (update) => {
    if (update) {
      let response = await updateUser(edit);
    }
    setOpen(false);
  };

  // DELETE

  const [dltOpen, setDltOpen] = React.useState(false);

  const handleDltClose = async (update) => {
    if (update) {
      let response = await deleteUser(edit.sl_no);
    }
    setDltOpen(false);
  };

  const handleClickDltOpen = () => {
    if (selectedRows.length > 0) {
      setDltOpen({
        dltOpen: true,
      });
      setEdit({
        sl_no: selectedRows[0].sl_no,
      });
    } else {
      alert("plz select atleast 1 row");
    }
  };

  // ADVANCE SEARCH

  const [advOpen, setAdvOpen] = React.useState(false);

  const [advance, setAdvance] = useState({
    cust_number: "",
    buisness_year: "",
    doc_id: "",
    invoice_id: "",
  });

  const { cust_number, buisness_year, doc_id, invoice_id } = advance;

  const changeAdvHandler = (e) => {
    const { name, value } = e.target;
    setAdvance({ ...advance, [name]: value });
  };

  const submitAdvHandler = async (e) => {
    e.preventDefault();
    let response = await advSrch(advance);
    console.log(response);
    if (response) {
      let data = response.users;
      setData(data.map((user, index) => ({ ...user, id: index })));
      setAdvance({
        cust_number: "",
        buisness_year: "",
        doc_id: "",
        invoice_id: "",
      });
    }
    handleAdvClose(false);
  };

  const handleClickAdvOpen = () => {
    setAdvOpen(true);
  };

  const handleAdvClose = () => {
    setAdvOpen(false);
  };

  return (
    <Box sx={{ backgroundColor: "#273d4a", paddingLeft: "20px" }}>
      <Grid container spacing={1}>
        <Grid item xs={4}>
          <ButtonGroup
            variant="outlined"
            aria-label="outlined primary button group"
          >
            <Button
              variant="contained"
              sx={{ color: "#eceff1", width: "11vw" }}
            >
              PREDICT
            </Button>
            <Button sx={{ color: "#eceff1", width: "10vw" }}>
              ANALYTICS VIEW
            </Button>

            <Advance
              cust_number={cust_number}
              buisness_year={buisness_year}
              doc_id={doc_id}
              invoice_id={invoice_id}
              changeAdvHandler={changeAdvHandler}
              submitAdvHandler={submitAdvHandler}
              advOpen={advOpen}
              handleClickAdvOpen={handleClickAdvOpen}
              handleAdvClose={handleAdvClose}
            />
          </ButtonGroup>
        </Grid>

        <Grid item xs={1}>
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={() => {
              window.location.reload(false);
            }}
          ></Button>
        </Grid>

        <Grid
          item
          xs={2}
          sx={{
            backgroundColor: "#273d4a",
            borderRadius: "6px",
            marginRight: "60px",
          }}
        >
          <TextField
            sx={{ bgcolor: "white", borderRadius: "4px" }}
            id="outlined-basic"
            label="Search Cusotmer Id"
            variant="filled"
          />
        </Grid>

        <Grid item xs={4}>
          <ButtonGroup variant="outlined" aria-label="outlined button group">
            <AddUsers />

            <EditUsers
              invoice_currency={invoice_currency}
              cust_payment_terms={cust_payment_terms}
              open={open}
              handleClose={handleClose}
              changeHandler={changeHandler}
              handleClickOpen={handleClickOpen}
            />

            <DeleteUsers
              dltOpen={dltOpen}
              handleClickDltOpen={handleClickDltOpen}
              handleDltClose={handleDltClose}
            />
          </ButtonGroup>
        </Grid>
        <Grid item xs={12}>
          <div style={{ height: 550, width: "100" }}>
            <DataGrid
              sx={{
                "& .MuiToolbar-root": {
                  color: "white",
                },
                border: "none",
                backgroundColor: "#293C4A",
                color: "white",
                "& .MuiDataGrid-columnSeparator--sideRight": {
                  display: "none",
                },
                "& .MuiDataGrid-columnHeaderTitle": {
                  color: "white",

                  textOverflow: "clip",
                  whiteSpace: "break-spaces",
                  lineHeight: 1,
                },
              }}
              getRowId={(row) => row.sl_no}
              rows={data}
              columns={col}
              rowsPerPageOptions={[5, 10, 15, 25, 50, 100]}
              checkboxSelection
              onSelectionModelChange={(ids) => {
                const selectedIDs = new Set(ids);
                const selectedRows = data.filter((row) =>
                  selectedIDs.has(row.sl_no)
                );
                setSelectedRows(selectedRows);
              }}
            />
          </div>
        </Grid>
      </Grid>
    </Box>
  );
}

export default MainData;
